# from frame import Frame
from crawler import Crawler
from frame import Frame

# 데이터 수집

crawler = Crawler()
crawler.topic_and_type()
crawler.speaker()
crawler.comment()
crawler.media()
crawler.time()
crawler.details()
crawler.url_and_title()

# print(crawler.Topic)
# print(crawler.Check_category)
# print(crawler.Speaker)
# print(crawler.Comment)
# print(crawler.Media)
# print(crawler.Time)
# print(crawler.Modification_time)
# print(crawler.Modification_reason)
# print(crawler.Details)
# print(crawler.Article_url)
# print(crawler.Article_title)

# Excel 파일에 데이터 넣기

frame = Frame()
frame.excel_maker()