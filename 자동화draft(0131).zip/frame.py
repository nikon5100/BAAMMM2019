import xlsxwriter
from crawler import Crawler

class Frame(object):  
    
    def excel_maker(self):

        crawler = Crawler()
        crawler.topic_and_type()
        crawler.speaker()
        crawler.comment()
        crawler.media()
        crawler.time()
        crawler.details()
        crawler.url_and_title()

        # Create a workbook and add a worksheet.
        workbook = xlsxwriter.Workbook('meta_data.xlsx')
        worksheet = workbook.add_worksheet()

        # Create a add format to cell

        cell_format_list = []
        color_list = ['#d9d9d9', '#ffe599', '#fff2cc', '#ffffff','#ea9999', '#fce5cd', '#ffffff']

        for i in range(0, len(color_list)):
            cell_format_list.append(workbook.add_format())
            cell_format_list[i].set_bg_color(color_list[i])
            cell_format_list[i].set_border(1)

        # Write some data headers.
        worksheet.write('A1', '메타데이터 종류', cell_format_list[0])
        worksheet.write('B1', '모니터링 담당자', cell_format_list[0])
        worksheet.write('C1', '', cell_format_list[0])

        fact_descriptions = (
            ['팩트', '서버번호', ''],
            ['', '뱃지번호', ''],
            ['', '토픽(정치, 경제 등)', crawler.Topic],
            ['', '테마(19대 대선, 새정부 등)', ''],
            ['', '팩트유형(검증 유형)', crawler.Check_category],
            ['', '기타성격', ''],
            ['', '팩트발생시간', ''],
            ['', '발언주체', crawler.Speaker],
            ['', '발언대상', ''],
            ['', '발언내용', crawler.Comment],
            ['', '사실/기타주체', ''],
            ['', '사실/기타대상', ''],
            ['', '사실/기타내용', ''],
            ['', '검증팩트의 영향력', '1.(네이버 실시간 검색어)\n2.(SNU 게시일 기준 기사 수)'],
        )

        fact_check_descriptions = (
            ['팩트체크', '참여언론사', crawler.Media],
            ['', '최초등록시간', crawler.Time],
            ['', '검증내용', crawler.Details],
            ['', '검증방식', ''],
            ['', '검증근거/출처', ''],
            ['', '검증근거/출처 URL', ''],
            ['', '검증기사제목', crawler.Article_title],
            ['', '검증기사URL', crawler.Article_url],
            ['', '최초검증결과', ''],
            ['', '검증결과수정여부', ''],
            ['', '수정검증결과', ''],
            ['', '검증결과 수정시간', crawler.Modification_time],
            ['', '검증결과 수정이유', crawler.Modification_reason],
            ['', '팩트검증 기사영향력', '(댓글수)\n(이모티콘 평가 수)'],                           
        )

        # Start from the first cell. Rows and columns are zero indexed.
        row = 2
        col = 0
        col_alphabets = ['A', 'B', 'C']

        for description in fact_descriptions: # 이중포문으로 칼럼 확장시 자동으로 추가될 수 있게 하자.
            for i in range(0, len(description)):

                worksheet.write(col_alphabets[i]+str(row), description[i], cell_format_list[i+1])
            row += 1

        for description in fact_check_descriptions: 
            for i in range(0, len(description)):
                worksheet.write(col_alphabets[i]+str(row), description[i], cell_format_list[i+4])
            row += 1

        #    worksheet.write(row, col,     data_kind)
        #    worksheet.write(row, col + 1, category)
        #    worksheet.write(row, col + 2, content)

        fact_merge_format = workbook.add_format({
            'bold': 1,
            'border': 1,
            'align': 'center',
            'valign': 'vcenter',
            'fg_color': '#ffe599'})

        fact_check_merge_format = workbook.add_format({
            'bold': 1,
            'border': 1,
            'align': 'center',
            'valign': 'vcenter',
            'fg_color': '#ea9999'})    

        worksheet.merge_range('A2:A15', '팩트', fact_merge_format)
        worksheet.merge_range('A16:A29', '팩트체크', fact_check_merge_format)

        workbook.close()

